/*!
MobilePriceCard 3.0.5
copyright (c) 2022 Mobile Price Card, Inc., (https://www.mobilepricecard.com/). All Rights Reserved
maintained by Max Ziebell, (https://maxziebell.de)
*/
/*
* Version-History
* 1.0	Initial release
* 1.1	Added interaction trigger, garbage collection and singleton functions
* 1.2	Android, iOS bridge, logEvent, UserInteraction event and Timer examples
* 1.3	Refactored ad bundle loading. Added heartbeat, url override by ad scene name and night mode
* 1.4	Added Handlebars support and events, added setNightmodeFilter and setData to the API
* 1.5	Added setLayoutFilter, setAdFilter and refactored code to be more stable
* 1.6	Added language to be transferred to ads, added an initial scale remover
* 1.7	Added requests, removed heartbeat, fixed callAppFunctionInterface
* 1.8	Fixed calling MobilePriceCard.setAdBundle with empty parameter to reset
* 1.9	Added openApplication command, exposed callAppFunctionInterface
* 2.0	Added external call interface MobilePriceCard.triggerCustomEvent
* 2.1	Added MobilePriceCard.openBrowser with two parameters (url, timeout)
* 2.2	Added forcePriceCard and forceAdCard (auto applied) as URL parameter switches
* 2.3	Added MobilePriceCard.globalCustomEvent
* 2.4	Added systemEvents, Fix to allow first scene as promotion
* 2.5	Added new commands to use openApplication, openBrowser and globalCustomEvent from ads, 
		Added data-log-type and data-log-info, added and reduced DOM event capture to pointerdown
* 2.6   Added new hypeDocument.gotoCard to be used in cards and ads,
		Fixed hasAds to return the boolean value and only set if needed
* 2.7   Improved ad filtering capabilities,
		Added setDefault, getDefault
		
––––– Major Version Bump as we change away from Handlebars –––––

* 3.0.0   Removed Handlebars, added Hype Action Events and Hype Reactive Behavior
* 3.0.1   Fixed small setData update bug pointed out in phone call
* 3.0.2   Latest versions of Hype Reactive Content and Hype Action Events
* 3.0.3   Check if iOS message handler is defined, added noPointerEventsOnChildren class
* 3.0.4   Updated Hype Reactive Content to v1.1.7 and added JSON detection in setData
* 3.0.5   Fixed bug with hype_scene_index being used in persistent symbols
          Added new commands nextCardWihBase, prevCardWithBase, nextCardInSequence, prevCardInSequence
          Added new command getCurrentCardInSequence, gotoCurrentCardInSequence

*/

if("MobilePriceCard" in window === false) window['MobilePriceCard'] = (function () {
	
	var _hasAds = false;
	var _adIndex = 0;
	var _isAdFrame = false;
	var _adBundle = [];
	var _adBundleOriginal = [];
	var _initAdCard = true;
	var _initPriceCard = true;
	
	var _hypeDocument;
	var _adCustomInfo = {};
	
	var _cardData = {};
	
	var _app = "MobilePriceCard";
	var _logMsg = _app + ": ";
	
	var _layoutFilter = 'EN';
	var _adFilter;
	
	var _default = {
		'nightmodeFilter' : 'invert()',
		'adFrameIdentifier' : 'forceAdCard',
		'cacheBuster':	null,
		'debug': false,
	}
	
	/**
	 * This function allows to override a global default by key or if a object is given as key to override all default at once
	 *
	 * @param {String} key This is the key to override
	 * @param {String|Function|Object} value This is the value to set for the key
	 */
	 function setDefault(key, value){
		//allow setting all defaults
		if (typeof(key) == 'object') {
			_default = key;
			return;
		}
	
		//set specific default
		_default[key] = value;
	}
	
	/**
	 * This function returns the value of a default by key or all default if no key is given
	 *
	 * @param {String} key This the key of the default.
	 * @return Returns the current value for a default with a certain key.
	 */
	function getDefault(key){
		// return all defaults if no key is given
		if (!key) return _default;
	
		// return specific default
		return _default[key];
	}

	/* Is either null (nop), true (function fired not complete) or a function to run */
	var _nextAction = null;

	/**
	 * This function is used to send a call to the application wrapper
	 *
	 * @param {String} cmd is the command (function name) to call in the app context
	 * @param {Array} args is an array of arguments that if applied (android) or passede along (iOS)
	 */
	function callAppFunctionInterface(cmd, args){
		if (window.hasOwnProperty('webkit')) {
			if (window.webkit.messageHandlers && window.webkit.messageHandlers[cmd]) {
				window.webkit.messageHandlers[cmd].postMessage(args);
			}
		}
		if (window.hasOwnProperty('Android')) {
			switch (cmd) {
				case 'logEvent': Android.logEvent(args[0], args[1]); break;
				case 'systemEvent': Android.systemEvent(args[0], JSON.stringify(args[1])); break; /* 2.4 difference to logEvent: has no public API */
				case 'openApplication': Android.openApplication(args[0]); break; /* 1.9 */
				case 'openBrowser': Android.openBrowser(args[0], args[1]); break; /* 2.1 */
				case 'globalCustomEvent': Android.globalCustomEvent(args[0], args[1]); break; /* 2.3 */
				default: Android.callAppFunctionInterface(cmd, JSON.stringify(args)); break; /* 1.9 */
			}
		}
	}

	/**
	 * This function is used to fire any actions (scene switches for now) that needed to wait for an iFrame to load
	 */
	function fireNextAction(){
		if (getDefault('debug')) console.log('_fireNextAction',_nextAction)
		if (typeof _nextAction == 'function') {
			// fire next action. Instant scene changes trigger sceneLoad and set _nextAction to null
			_nextAction();
			// if _nextAction is still set make it true (and not a function) until transition is over then sceneLoad sets _nextAction to null
			if (_nextAction) _nextAction = true;
		}
	}


	/**
	 * This function allows to force scenes into a specific layout name.
	 *
	 * @param {String} layoutName to be forced if possible
	 */
	function setLayoutFilter(layoutName) {
		systemEvent('setLayoutFilter', layoutName);
		_layoutFilter = layoutName? layoutName : null;
		if (_hypeDocument) _hypeDocument.showLayoutNamed(layoutName);
	}


	function removeInitalScale(){
		var metaElm = document.querySelector('head meta[name="viewport"]');
		metaElm.setAttribute('content', metaElm.getAttribute('content').split('initial-scale=1.0').join('').split(', ,').join(''));
	}


	/**
	 * This function allows to filter the current adBundle to match a start pattern
	 *
	 * @param {String} starts 
	 */
	function setAdFilter(filterFunction) {
		_adFilter = typeof filterFunction === 'function' && filterFunction.length === 1? filterFunction : null;
		setAdBundle(_adBundleOriginal);
	}
	
	
	/**
	 * This function updates the URLs for ad cards to be loaded sequentially in the iFrames. URLs can have the search paramter '?cardByIndex=NUMBER' or '?cardByName=NAME' to start on a specific ad card.
	 *
	 * @param {Array} urlBundle with array of urls to the HTML-file containing the ads
	 */
	function setAdBundle(adBundle){
		// reset bundle
		_adBundleOriginal = _adBundle = [];
		_hasAds = false;
	
		if (adBundle && Array.isArray(adBundle) && adBundle.length > 0) {
			// user passed in an array of ads
			_adBundleOriginal = adBundle;
			
			// we want to filter
			if(_adFilter) {
				_adBundle = _adFilter(_adBundleOriginal);
				_hasAds = _adBundle.length > 0;
			} else {
				_adBundle = _adBundleOriginal;
				_hasAds = true;
			}
	
			// return number of ads set (after filter)
			return _adBundle.length;
		}
	
		// return false if they passed in an invalid bundle
		return false;
	}
	
	
	/**
	 * This function creates a filter function based on a stringAtBeginning.
	 *
	 * @param {String} stringAtBeginning
	 * @return {Function}
	 */
	function filterBeginsWith(stringAtBeginning){
		return function(bundle) {
			return bundle.slice().filter(function(url){
				var str = url.split(/(\\|\/)/g).pop(); // get last part of the url
				return str.startsWith(stringAtBeginning); // check if it starts with the given string
			});
		}
	}
	
	/**
	 * This function creates a filter function based on a stringAtBeginning.
	 *
	 * @param {String} stringToContain
	 * @return {Function}
	 */
	function filterContains(stringToContain){
		return function(bundle) {
			return bundle.slice().filter(function(url){
				var str = url.split(/(\\|\/)/g).pop(); // get last part of the url
				return str.includes(stringToContain); // check if it includes the given string
			});
		};
	}

	/**
	 * This function allows to enable or disable ads in a card bundle. It currently defaults to false and is set to true by setAdBundle
	 *
	 * @param {Boolean} bool set if the card bundle should display ads
	 */
	function hasAds(bool){
		if (bool!=undefined) _hasAds = !!bool;
		return !!_hasAds;
	}



	/**
	 * This function checks if a Hype document declared itself an ad or is running in a iFrame (fallback). Best practice is to declare it.
	 *
	 * @param {Boolean} bool use to set if bundle is a ad mannualy
	 * @return {Boolean} previous set value or auto-detect by frame hierarchy
	 */
	function isAdFrame(bool){
		if (bool!=null) _isAdFrame = !!bool; /* set internal store if provided */
		if (location.search.indexOf('forcePriceCard')!=-1) return false; /* since 2.2 -> allow forcePriceCard */
		return _isAdFrame || location.search.indexOf('forceAdCard')!=-1 || false; /* since 2.2 -> removed auto detect assuming false as default */
	}

	/**
	 * This function checks if a scene is an ad card slot. Currently, this is done by checking the first two letters of the scene name to be 'Ad'
	 *
	 * @param {String} name to test on
	 * @return {Boolean} determing if string starts with 'Ad'
	 */
	function isAdName(name){
		return name.indexOf('Ad')==0;
	}

	/**
	 * This function enable or disables the night mode. This is done by applying the nightmodeFilters that can be set with setNightmodeFilter and default to 'invert()'
	 *
	 * @param {Bolean} bool is used to enable or disable the mode
	 */
	function setNightmode(bool){
		var htmlStyle = document.querySelector('html').style;
		htmlStyle.webkitFilter = bool ? getDefault('nightmodeFilter') : null;
		htmlStyle.filter = htmlStyle.webkitFilter;
	}

	/**
	 * This function is determins if we in a Hype Preview. 
	 *
	 * @return {Bolean} Return true if not on device
	 */
	function isHypePreview(){
		return window.location.href.indexOf("127.0.0.1:") != -1 &&
			window.location.href.indexOf("/preview/") != -1 &&
			navigator.platform.toUpperCase().indexOf('MAC')>=0;
	}

	/**
	 * This function is determins if we in the Hype IDE.
	 *
	 * @return {Bolean} Return true if not on device
	 */
	function isHypeIDE(){
		return window.location.href.indexOf("/Hype/Scratch/HypeScratch.") != -1;
	}

	/**
	 * This function allows to set the nightmode filter property and default to 'invert()'. Please use filters found in https://developer.mozilla.org/en-US/docs/Web/CSS/filter. 
	 *
	 * @param {String} filter These are the filter to be used when switching to nightmode
	 */
	function setNightmodeFilter(filter){
		setDefault('nightmodeFilter', filter || 'invert()');
	}


	/**
	 * This function sets the data object and default to an empty objects
	 *
	 * @param {Object} data Contains the data to be used by Hype Reactive Content
	 */
	function setData(data){
		_cardData = data || {};
		if (_hypeDocument) {
			// Expand JSON
			_cardData = expandJsonStrings (_cardData);
			// New in 3.0.x, we assign the card data to custom data
			if (_hypeDocument.enableReactiveCustomData){
				_hypeDocument.enableReactiveCustomData(_cardData);	
			} else {
				_hypeDocument.customData = Object.assign({}, _cardData);	
			}
		}
	}
	
	function setDataForPreview(data){
		if(isHypePreview()) setData(data);
	}
	
	/**
 	 * Recursively expands all JSON strings contained within an object or array.
 	 *
 	 * @param {Object|Array|string} obj - The object or array to expand, or a JSON string to parse and expand.
 	 * @returns {Object|Array|string} - A copy of the input object or array with all JSON strings replaced by their expanded values, or the original JSON string if parsing fails.
 	 */
	function expandJsonStrings(obj) {
		// If the input is a string, check if it starts with an object or an array
		if (typeof obj === 'string') {
			const trimmed = obj.trim();
			
			if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
				try {
					return expandJsonStrings(JSON.parse(trimmed));
				} catch (e) {
					// If parsing fails, just return the original string
					return obj;
				}
			} else {
				// If the input string does not start with an object or an array, return it as-is
				return obj;
			}
		}
	
		// If the input is an array, recursively expand each element
		if (Array.isArray(obj)) {
			return obj.map(expandJsonStrings);
		}
	
		// If the input is an object, recursively expand each value
		if (typeof obj === 'object' && obj !== null) {
			const newObj = {};
			for (const [key, value] of Object.entries(obj)) {
				newObj[key] = expandJsonStrings(value);
			}
			return newObj;
		}
	
		// Otherwise, just return the input as-is
		return obj;
	}

	/**
	 * This functions allows to set an URL addition for the iFrames to make sure we are breaking any cache. Useful for local testing as device wrapper have control over the cache probably not needed in production.
	 * 
	 * @param {String} str is added to ad urls as a parameter
	 */
	function setCacheBuster(str){
		setDefault('cacheBuster', str);
	}

	/**
	 * This function allows to bind an ad scene to load a specific URL. Hence, the ad is not taken from the sequence.
	 *
	 * @param {String} adName is gets bound to specific ad url
	 * @param {String} url of the ad or null to remove
	 */
	function setAdSceneNameToUrl(adName, url) {
		if (url) {
			_adCustomInfo[adName] = { url: url }
		} else {
			if (_adCustomInfo.hasOwnProperty(adName)) 
				delete _adCustomInfo[adName];
		}
	}

	/**
	 * This function allows to send an log event to the wrapper
	 *
	 * @param {String} type of event
	 * @param {String} info about the event
	 */
	function logEvent(type, info){
		console.log('logEvent', type, info);
		callAppFunctionInterface('logEvent',[type, info]);
	}

	/**
	 * This function allows to send an system event to the wrapper
	 *
	 * @param {String} type of event
	 * @param {String} info about the event
	 */
	function systemEvent(type, info){
		if (getDefault('debug')) console.log("systemEvent",type, info);
		callAppFunctionInterface('systemEvent',[type, info]);
	}

	/**
	 * This function allows to send an open application event to the wrapper
	 * New since 1.9
	 *
	 * @param {String} name identifier of application
	 */
	function openApplication(name){
		callAppFunctionInterface('openApplication',[name]);
	}

	/**
	 * This function allows to send an open browser event to the wrapper
	 * New since 2.1
	 *
	 * @param {String} url to be openend
	 * @param {Number} timeout in seconds (default: 120)
	 */
	function openBrowser(url, timeout){
		callAppFunctionInterface('openBrowser',[url, timeout||120]);
	}

	/**
	 * This function allows to send an global custom event to the wrapper
	 * New since 2.3
	 *
	 * @param {String} cmd to be sent
	 * @param {Boolean} echo the cmd to self 
	 */
	 function globalCustomEvent(cmd, echo){
		callAppFunctionInterface('globalCustomEvent',[cmd, echo||false]);
	}

	/**
	 * This internal function is used to find or create the iFrame wrapper. If there is a ad card frame element on scene it uses that container else it creates one (internal)
	 * @param {HTMLElement} rootElm to start the search on
	 * @return {HTMLElement} element to add the iFrame too
	 */
	function getAdCardElement(rootElm){
		
		var frameElm = rootElm.querySelector('.adCard-Container');
		if (!frameElm){
			frameElm = document.createElement('div');
			frameElm.style.zIndex = '1000';
			frameElm.style.width = '100%';
			frameElm.style.height = '100%';
			frameElm.style.position = 'absolute';
			frameElm.style.top = '0px';
			frameElm.style.left = '0px';
			frameElm.className = "adCard-Container";
			rootElm.appendChild(frameElm);
		}
		return frameElm;
	}

	/**
	 * This internal function marks a URL as an ad
	 * @param {String} url to be manipulated
	 * @return {String} url string with ad marker
	 */
	function addIdentifierToAdFrameURL(url){
		if (url.indexOf('?')==-1) return url += '?'+ getDefault('adFrameIdentifier');
		return url+'&'+ getDefault('adFrameIdentifier');
	}

	/**
	 * This internal function to make sure we are getting a fresh copy per session as _cacheBuster is defined on pageload
	 * @param {String} url to be manipulated
	 * @return {String} url string with cacheBuster if set
	 */
	function addCacheBusterToURL(url){
		if (getDefault('cacheBuster')){
			if (url.indexOf('?')==-1) return url += '?'+ getDefault('cacheBuster');
			return url+'&'+ getDefault('cacheBuster');
		} else {
			return url;
		}
	}

	/**
	 * This internal function adds the current layoutfilter to an url
	 * @param {String} url to be manipulated
	 * @return {String} url string with cacheBuster if set
	 */
	function addLayoutFilterToURL(url){
		if (_layoutFilter){
			if (url.indexOf('?')==-1) return url += '?layoutFilter='+_layoutFilter;
			return url+'&layoutFilter='+_layoutFilter;
		} else {
			return url;
		}
	}

	/**
	 * This internal function to fetch the current adBundleUrl while making sure the index is in the adBundle length
	 * @return {String} url of current add from bundle
	 */
	function getAdBundleUrl(){
		_adIndex %= _adBundle.length;
		return _adBundle[_adIndex]
	}

	/**
	 * This internal function to fetch a custom ad url if set for a specific ad frame (scene name) using setAdSceneNameToUrl
 	 * @param {String} name of the ad frame (scene name)
	 * @return {String} url string if set else null
	 */
	function getCustomAdUrlForAdName(name){
		var adCustomInfo = _adCustomInfo[name];
		return adCustomInfo? adCustomInfo.url? adCustomInfo.url:null :null
	}

	/**
	 * New in v2.0: This function forwards command to custom behavior and command pipeline in the card deck
 	 * @param {String} name of behavior 
	 * @return {Boolean} if it was able to trigger (success)
	 */
	function triggerCustomEvent(cmd) {
		if (!window.hasOwnProperty('HYPE')) return false;
		var success = false;
		Object.values(window.HYPE.documents).forEach(function(hypeDocument){
			// trigger behavior
			hypeDocument.triggerCustomBehaviorNamed(cmd);
			// auto trigger command pipeline if function is present
			// hint: is anyway triggered if pipe is present so gating against that
			if (cmd.indexOf('|')==-1 && typeof hypeDocument[cmd] == 'function'){
				hypeDocument.triggerCustomBehaviorNamed(cmd+'|');
			}
			success = true;
		});
		return success;
	}

	/**
	 * extendHype (internal)
	 * @param {Object} hypeDocument contains the API
	 * @param {HTMLElement} element pointing to the document container
	 * @param {Object} event containing type
	 * @return {Boolean} return false to abort init
	 */
	function extendHype(hypeDocument, element, event) {

		/* fix: remove any inital scale */
		removeInitalScale();

		/* remember the Hype singleton once we have loaded */
		_hypeDocument = hypeDocument;

		/* start */
		var sceneNames = hypeDocument.sceneNames();
		var sceneNamesUnique = sceneNames.filter(function(value, index, self){
			return self.indexOf(value) === index
		});

		if(sceneNames.length != sceneNamesUnique.length){
			alert('MobilePriceCard: Please use unique scene names!');
			return false;
		}

		/* set any inital data */
		setData(_cardData);

		/* switch implementation between MobilPriceCard or MobilePriceAd */
		if (isAdFrame()) {
			/* MobilePriceAd Hype Interface */
			function CommandPipeArguments(args){
				return JSON.stringify([].slice.call( args? args:[] )).slice(1, -1);
			}

			hypeDocument.nextCard = function(optionalTransition, optionalDuration){
				hypeDocument.triggerCustomBehaviorNamed('nextCardFromAd|'+CommandPipeArguments(arguments));
			}
			
			hypeDocument.prevCard = function(optionalTransition, optionalDuration){
				hypeDocument.triggerCustomBehaviorNamed('prevCardFromAd|'+CommandPipeArguments(arguments));
			}
			
			hypeDocument.gotoCard = function(name, optionalTransition, optionalDuration){
				hypeDocument.triggerCustomBehaviorNamed('gotoCardFromAd|'+CommandPipeArguments(arguments));
			}

			hypeDocument.logEvent = function(type, info){
				hypeDocument.triggerCustomBehaviorNamed('logEventFromAd|'+CommandPipeArguments(arguments));
			}

			hypeDocument.enableCardInteraction = function(){
				// we need to wait for runtime to be ready
				setTimeout(function(){
					hypeDocument.triggerCustomBehaviorNamed('enableCardInteraction');
				},1);
			}

			/* 3.0.5 functions for sequences are not exposed to parent tbd. */
			
			/* since v1.9, v2.5 */
			MobilePriceAd.openApplication = function(name){
				hypeDocument.triggerCustomBehaviorNamed('openApplicationFromAd|'+CommandPipeArguments(arguments));
			}
			
			MobilePriceAd.globalCustomEvent = function(cmd, echo){
				hypeDocument.triggerCustomBehaviorNamed('globalCustomEventFromAd|'+CommandPipeArguments(arguments));
			}
			
			MobilePriceAd.openBrowser = function(url, timeout){
				hypeDocument.triggerCustomBehaviorNamed('openBrowserFromAd|'+CommandPipeArguments(arguments));
			}

			/* parse url params */
			var params = new URLSearchParams(location.search); 

			/* set layout filter if set */
			if (params.has('layoutFilter')) {
				setLayoutFilter(params.get('layoutFilter'))
			}

			/* go to card if set (either by index or name) */
			if (params.has('cardByIndex')) {
				_adIndex = parseInt(params.get('cardByIndex')) || 0;
				_adIndex %= sceneNames.length;
				hypeDocument.showSceneNamed(sceneNames[_adIndex]);
			} else if (params.has('cardByName')) {
				hypeDocument.showSceneNamed(params.get('cardByName'));
			} else {
				hypeDocument.showSceneNamed(sceneNames[0]);
			}
			
			/* fire next action once we are here as the iFrame is loaded */
			hypeDocument.triggerCustomBehaviorNamed('fireNextAction');


			/* remove unwanted API calls */
			[	'hasAds',
				'fireNextAction',
				'setCacheBuster',
				'setNightmode',
				'setAdSceneNameToUrl',
				'setNightmodeFilter',
				'setLayoutFilter',
				'setAdFilter',
				'triggerCustomEvent',
				/* remove in 3.0.5 */
				'nextCardWithBase',
				'prevCardWithBase',
				'defineCardSequence',
				'nextCardInSequence',
				'prevCardInSequence',
				'gotoCurrentCardInSequence',
				'getCurrentCardInSequence',
			].forEach(function(key){
				delete window.MobilePriceAd[key];
			})
			delete window.MobilePriceCard;

		} else {
			/* MobilePriceCard Hype Interface */
			
			/* Hype Event */
			systemEvent('HypeEventName', 'HypeDocumentLoad');

			/**
			 * This internal function to prepare an iFrame and set its source before whe transition to it. It always prepares the first layout.
			 * @param {String} adFrameSceneName is the name of the scene we are preparing
			 * @return {Boolean} The return indicates if the frame was created
			 */
			 hypeDocument.prepareAdFrame = function (adFrameSceneName){
				var firstLayout = hypeDocument.layoutsForSceneNamed(adFrameSceneName)[0];
				var adFrameSceneElm = element.querySelector(':scope > [hype_scene_index="'+firstLayout._+'"]');

				var frameElm = getAdCardElement(adFrameSceneElm);
				if (getDefault('debug')) console.log(_logMsg+"frameElm", frameElm);

				// AD FRAME
				if (!frameElm.querySelector('.adCard-iFrame')) {

					if (getDefault('debug')) console.log(_logMsg+"We got no .adCard-iFrame so create one");

					// We got no iFrame so create one (sidenote: created ad frames are garbage collected in the function sceneLoad)
					var customAdUrl = getCustomAdUrlForAdName(adFrameSceneName.trim());
					var adCardUrl = addIdentifierToAdFrameURL(addCacheBusterToURL(addLayoutFilterToURL( customAdUrl || getAdBundleUrl() )));
					frameElm.innerHTML = '<iframe class="adCard-iFrame" src="'+adCardUrl+'" width="100%" height="100%" frameborder="0">';
					if (!customAdUrl) _adIndex++;
					
					// success: We created an ad card iFrame
					return true;

				} else {
					// failure: There is already an ad card iFrame
					return false;
				}
			}
			
			
			/**
			 * This function is for regular scene switching to a specific scene, but catches any changes to a scene with an ad. In that case this function loads the ad into an iFrame and then switches to the scene once the ad has loaded.
			 *
			 * @param {Number} optionalTransition Is a Hype constant that defines the transition type
			 * @param {Number} optional Duration of the transition
			 */
			hypeDocument.gotoCard = function(name, optionalTransition, optionalDuration){
				
				// if there is still a next action to be triggered or it is waiting for the transition to complete return
				if (_nextAction) return;
			
				var index = sceneNames.indexOf(name);
				if (index==-1) {
					if (getDefault('debug')) console.log(_logMsg+"gotoSceneName ", gotoSceneName," does not exist");
					return false;
				}
				var gotoSceneName = sceneNames[index];
				
				if (!_hasAds && isAdName(gotoSceneName)) {
					if (getDefault('debug')) console.log(_logMsg+"gotoSceneName ", gotoSceneName," has no ads");
					return false;
				}
				
				if (getDefault('debug')) console.log(_logMsg+"gotoCard -> gotoSceneName", gotoSceneName);
				
				_nextAction = function(){
					hypeDocument.showSceneNamed(gotoSceneName, optionalTransition, optionalDuration)
				}
			
				if(isAdName(gotoSceneName) && _hasAds) {
					hypeDocument.prepareAdFrame(gotoSceneName) || fireNextAction();
				} else {
					fireNextAction();
				}
			}
			
			/**
			 * This function is for regular scene switching to the next scene, but catches any changes to a scene with an ad. In that case this function loads the ad into an iFrame and then switches to the scene once the ad has loaded.
			 *
			 * @param {Number} optionalTransition Is a Hype constant that defines the transition type
			 * @param {Number} optional Duration of the transition
			 */
			hypeDocument.nextCard = function(optionalTransition, optionalDuration){
				
				// if there is still a next action to be triggered or it is waiting for the transition to complete return
				if (_nextAction) return;

				var index = sceneNames.indexOf(hypeDocument.currentSceneName()) + 1;
				var nextSceneName = sceneNames[index] || sceneNames[0];
				
				if (!_hasAds){
					while (isAdName(nextSceneName)){
						index = sceneNames[index+1]? index+1 : 0;
						nextSceneName = sceneNames[index];
					}
				}
				
				if (getDefault('debug')) console.log(_logMsg+"nextCard -> nextSceneName", nextSceneName);
				
				_nextAction = function(){
					hypeDocument.showSceneNamed(nextSceneName, optionalTransition, optionalDuration)
				}

				if(isAdName(nextSceneName) && _hasAds) {
					hypeDocument.prepareAdFrame(nextSceneName) || fireNextAction();
				} else {
					fireNextAction();
				}
			}


			/**
			 * This function is for regular scene switching to the previous scene, but catches any changes to a scene with an ad. In that case this function loads the ad into an iFrame and then switches to the scene once the ad has loaded.
			 *
			 * @param {Number} optionalTransition Is a Hype constant that defines the transition type
			 * @param {Number} optionalDuration Is the duration of the transition
			 */
			hypeDocument.prevCard = function(optionalTransition, optionalDuration){
				if (_nextAction) return;

				var index = sceneNames.indexOf(hypeDocument.currentSceneName()) - 1;
				var nextSceneName = sceneNames[index] || sceneNames[sceneNames.length-1];

				if (!_hasAds){
					while (isAdName(nextSceneName)){
						index = index-1>=0? index-1 : sceneNames.length-1;
						nextSceneName = sceneNames[index];
					}
				}

				if (getDefault('debug')) console.log(_logMsg+"prevCard -> nextSceneName", nextSceneName);
				
				_nextAction = function(){
					hypeDocument.showSceneNamed(nextSceneName, optionalTransition, optionalDuration)
				}
				
				if(isAdName(nextSceneName) && _hasAds) {
					hypeDocument.prepareAdFrame(nextSceneName) || fireNextAction();
				} else {
					fireNextAction();
				}
			}

			/**
			 * function to cycle through cards with a specific base name
			 * @param {String} direction 'next' or 'prev'
			 * @param {String} base base name of the cards to cycle through
			 * @param {Number} optionalTransition Is a Hype constant that defines the transition type
			 * @param {Number} optionalDuration Is the duration of the transition
			 * 
			 */
			hypeDocument.cycleToCardWithBase = function (direction, base, optionalTransition, optionalDuration) {
				const sceneNames = hypeDocument.sceneNames();
				const currentIndex = sceneNames.indexOf(hypeDocument.currentSceneName());
				const sceneCount = sceneNames.length;
				const step = direction === 'next' ? 1 : -1;
			
				for (let offset = 1; offset < sceneCount; offset++) {
					const index = (currentIndex + step * offset + sceneCount) % sceneCount;
					const sceneName = sceneNames[index];
			
					if (sceneName && sceneName.indexOf(base) === 0) {
						hypeDocument.gotoCard(sceneName, optionalTransition, optionalDuration);
						break;
					}
				}
			};
			
			/**
			 * function to cycle through cards with a specific base name
			 * @param {String} base base name of the cards to cycle through
			 * @param {Number} optionalTransition Is a Hype constant that defines the transition type
			 * @param {Number} optionalDuration Is the duration of the transition
			 * 
			 * @since 3.0.5
			 */
			hypeDocument.nextCardWithBase = function (base, optionalTransition, optionalDuration) {
				hypeDocument.cycleToCardWithBase('next', base, optionalTransition, optionalDuration);
			};
			
			/**
			 * function to cycle through cards with a specific base name
			 * @param {String} base base name of the cards to cycle through
			 * @param {Number} optionalTransition Is a Hype constant that defines the transition type
			 * @param {Number} optionalDuration Is the duration of the transition
			 * 
			 * @since 3.0.5
			 */
			hypeDocument.prevCardWithBase = function (base, optionalTransition, optionalDuration) {
				hypeDocument.cycleToCardWithBase('prev', base, optionalTransition, optionalDuration);
			};

			/* variable to store the sequences, singleton for now (preped for more) */
			hypeDocument._sequences = {};

			/**
			 * function to define the sequence of cards
			 * @param {Array} cardSequence array of card names
			 *
			 * @since 3.0.5
			 */
			hypeDocument.defineCardSequence = function (cardSequence) {
				if (typeof cardSequence === 'string') {
					cardSequence = cardSequence.split(',').map(function (cardName) {
						return cardName.trim();
					});
				}
				if (!Array.isArray(cardSequence)) {
					console.warn('defineCardSequence requires an array of card names');
					return;
				}
				if (cardSequence.length < 2) {
					console.warn('defineCardSequence requires at least 2 cards');
					return;
				}
				hypeDocument._sequences['default'] = cardSequence.slice();
			}

			/**
			 * function to go to next card in the sequence
			 * @param {Number} optionalTransition Is a Hype constant that defines the transition type
			 * @param {Number} optionalDuration Is the duration of the transition
			 *
			 * @since 3.0.5 
			 */
			hypeDocument.nextCardInSequence = function (optionalTransition, optionalDuration) {
				const sequence = hypeDocument._sequences['default'];
				if (sequence) {
					sequence.push(sequence.shift());
					hypeDocument.gotoCard(sequence[0], optionalTransition, optionalDuration);
				}
			}

			/**
			 * function to go to previous card in the sequence
			 * @param {String} cardName name of the card
			 * @param {Number} optionalTransition Is a Hype constant that defines the transition type
			 * @param {Number} optionalDuration Is the duration of the transition
			 *
			 * @since 3.0.5 
			 */
			hypeDocument.prevCardInSequence = function (optionalTransition, optionalDuration) {
				const sequence = hypeDocument._sequences['default'];
				if (sequence) {
					sequence.unshift(sequence.pop());
					hypeDocument.gotoCard(sequence[0], optionalTransition, optionalDuration);
				}
			}

			/**
			 * function to get the current card in the sequence
			 * @return {String} name of the card
			 *
			 * @since 3.0.5
			 */
			hypeDocument.getCurrentCardInSequence = function () {
				const sequence = hypeDocument._sequences['default'];
				return sequence? sequence[0] : null;
			}

			
			/**
			 * function to go to the currenct card in the sequence
			 * @param {Number} optionalTransition Is a Hype constant that defines the transition type
			 * @param {Number} optionalDuration Is the duration of the transition
			 * 
			 * @since 3.0.5
			 */
			hypeDocument.gotoCurrentCardInSequence = function (optionalTransition, optionalDuration) {
				const sequence = hypeDocument._sequences['default'];
				if (sequence) {
					MobilePriceCard.gotoCard(sequence[0], optionalTransition, optionalDuration);
				}
			}

			/* alias for log function */
			hypeDocument.logEvent = logEvent;

			/* alias for various ad card functions */
			hypeDocument['#logEventFromAd'] = function(type, info){
				hypeDocument.logEvent(type, info);
			}

			hypeDocument['#systemEventFromAd'] = function(type, info){
				systemEvent(type, info);
			}
			
			hypeDocument['#openBrowserFromAd'] = function(url, timeout){
				openBrowser(url, timeout);
			}

			hypeDocument['#globalCustomEventFromAd'] = function(cmd, echo){
				globalCustomEvent(cmd, echo);
			}

			hypeDocument['#openApplicationFromAd'] = function(name){
				openApplication(name);
			}

			hypeDocument['#gotoCardFromAd'] = function(name, optionalTransition, optionalDuration){
				hypeDocument.gotoCard(name, optionalTransition, optionalDuration);
			}

			hypeDocument['#nextCardFromAd'] = function(optionalTransition, optionalDuration){
				hypeDocument.nextCard(optionalTransition, optionalDuration);
			}

			hypeDocument['#prevCardFromAd'] = function(optionalTransition, optionalDuration){
				hypeDocument.prevCard(optionalTransition, optionalDuration);
			}

			hypeDocument.onGlobalBehavior = function(behavior){
				switch(behavior){
					case '#fireNextAction':
						fireNextAction();
						break;

					case '#enableCardInteraction':
						// the frame has requested interactivity so we enable and flag the wish in case a transitions is taking place
						var sceneElm = document.getElementById(this.currentSceneId());
						getAdCardElement(sceneElm).style.setProperty('pointer-events', 'auto');
						sceneElm.dataset.interaction = 'true';
						break;
				}
			};	

			/* remove unwanted API calls */
			[	'isAdBundle',
				'enableCardInteraction',
			].forEach(function(key){
				delete window.MobilePriceCard[key];
			})

			delete window.MobilePriceAd;
		}

		/* setup firing of user interaction events */
		var DOMEventTypes = ['pointerdown'];
		DOMEventTypes.filter(function(DOMEventType){
			document.addEventListener(DOMEventType, function(e){
				/* 1.7 send full path to logEvent */
				var isDisplayAd = !isAdFrame() && isAdName(hypeDocument.currentSceneName())
				var url = isDisplayAd? getCurrentAd(): window.location.href;
				systemEvent(DOMEventType, url);
				
				/* New since 2.5 */
				if (e.target) {
					var type = e.target.getAttribute('data-log-type');
					var info = e.target.getAttribute('data-log-info');
					if (type && info) {
						logEvent(type, info);
					}
				}
				
				hypeDocument.triggerCustomBehaviorNamed('UserInteraction');
			}, { passive: true });
		});

		/* New in v2.0: trigger an internal HypeDocumentEvent in the Hype user functions (if present) */
		if (typeof hypeDocument.functions().HypeDocumentLoad == 'function'){
			hypeDocument.functions().HypeDocumentLoad(hypeDocument, element, event);
		}
		
		/* new in v2.6, added .noPointerEventsOnChildren in 3.0.3 */
		addHelperStyle(
			'.noPointerEvents, .noPointerEvents *, .noPointerEventsOnChildren * { pointer-events: none !important; }'
		);
	}
	
	function addHelperStyle(css) {
	  var style = document.createElement('style');
	  style.type = 'text/css';
	  style.innerHTML = css;
	  document.getElementsByTagName('head')[0].appendChild(style);
	}

	/**
	 * sceneLoad (internal)
	 * @param {Object} hypeDocument contains the API
	 * @param {HTMLElement} element pointing to the document container
	 * @param {Object} event containing type
	 * @return {Boolean} return false to override scene load functions from IDE
	 */
	function sceneLoad(hypeDocument, element, event) {
		if (getDefault('debug')) console.log(_logMsg+"sceneLoad _nextAction set to null", hypeDocument.currentSceneName(),hypeDocument.currentLayoutName() )

		_nextAction = null
		var sceneElm = element;

		if (isAdFrame()) {
			// THIS IS AN AD 
			if (getDefault('debug')) console.log(_logMsg+"This is an ad card");

			// ignore first load
			if (_initAdCard){
				_initAdCard = false;
				return false;
			}

		} else {
			// only runs once on first document load
			// check if first scene is an ad on 
			if (_initPriceCard){
			 	_initPriceCard = false;
				 var sceneNames = hypeDocument.sceneNames();
				 if(isAdName(sceneNames[0])) {
					if(_hasAds){
						hypeDocument.prepareAdFrame(sceneNames[0]);
					} else {
						hypeDocument.nextCard();
						return;
					}
				}
			}

			// THIS IS A CARD DECK
			// Hype Event
			systemEvent('HypeEventName', 'HypeSceneLoad');

			var sceneIndex = hypeDocument.sceneNames().indexOf(hypeDocument.currentSceneName());

			if (isAdName(hypeDocument.currentSceneName()) ){
				
				var frameElm = getAdCardElement(sceneElm);
				if (getDefault('debug')) console.log(_logMsg+"frameElm", frameElm);

				// AD FRAME
				if (frameElm.querySelector('.adCard-iFrame')) {
					if (getDefault('debug')) console.log(_logMsg+"We got .adCard-iFrame");

					systemEvent('currentCardInfo', {
						
						/* card type */
						'currentCardType': 'adCard',
						
						/* card extra meta */
						'adFrameUrl': getCurrentAd(),

						/* general meta */
						'currentCardName': hypeDocument.currentSceneName(),
						'currentCardNumber': sceneIndex,
						'currentCardLayoutName': hypeDocument.currentLayoutName(),
						'currentCardLayoutFilter': _layoutFilter,

					});

					// enable interactions if needed
					var pointerEventsValue = element.dataset.interaction? 'auto': 'none';
					frameElm.style.setProperty('pointer-events', pointerEventsValue);//, 'important');
					if (element.dataset.interaction) delete element.dataset.interaction;
				}

			} else {

				systemEvent('currentCardInfo', {
					
					/* card type */
					'currentCardType': 'PriceCard',

					/* general meta */
					'currentCardName': hypeDocument.currentSceneName(),
					'currentCardNumber': sceneIndex,
					'currentCardLayoutName': hypeDocument.currentLayoutName(),
					'currentCardLayoutFilter': _layoutFilter,

				});
			}

			// garbage collect all ad frames in document not in the current scene
			document.querySelectorAll('#'+hypeDocument.documentId()+' .adCard-iFrame').forEach(function(adCardElm){
				if (!element.contains(adCardElm)) {
					adCardElm.src = 'about:blank';
					setTimeout(function(){
						adCardElm.remove();
					},10)
				}
			});
		}
	}

	/**
	 * sceneUnload (internal)
	 * @param {Object} hypeDocument contains the API
	 * @param {HTMLElement} element pointing to the document container
	 * @param {Object} event containing type
	 */
	function sceneUnload(hypeDocument, element, event) {
		// Hype Event
		if (!isAdFrame()) systemEvent('HypeEventName', 'HypeSceneUnload');
	}

	function getCurrentAd(){
		if (!isAdFrame() && isAdName(_hypeDocument.currentSceneName())){
			var sceneElm = document.getElementById(_hypeDocument.currentSceneId());
			var frameElm = getAdCardElement(sceneElm);
			return frameElm.querySelector('.adCard-iFrame').getAttribute('src');
		} else {
			return null;
		}
	}

	function layoutRequest(hypeDocument, element, event) {
		// failures in matches are currently handled by the Hype Runtime
		return _layoutFilter;
	}

	/* Setup Hype listeners */
	if("HYPE_eventListeners" in window === false) { window.HYPE_eventListeners = Array();}

	window.HYPE_eventListeners.push({"type":"HypeLayoutRequest", "callback":layoutRequest});
	window.HYPE_eventListeners.push({"type":"HypeDocumentLoad", "callback":extendHype});
	window.HYPE_eventListeners.push({"type":"HypeSceneLoad", "callback":sceneLoad});
	window.HYPE_eventListeners.push({"type":"HypeSceneUnload", "callback":sceneUnload});

	/* Reveal Public interface to window['MobilePriceCard'] */
	var API = {
		version: '3.0.5',
		
		fireNextAction: fireNextAction,
		
		hasAds: hasAds,
		isAdBundle: isAdFrame,
		
		setAdBundle: setAdBundle,
		setNightmode: setNightmode,
		setCacheBuster: setCacheBuster,
		setAdSceneNameToUrl: setAdSceneNameToUrl,
		setNightmodeFilter: setNightmodeFilter,
		setData: setData,
		setDataForPreview: setDataForPreview,
		setLayoutFilter: setLayoutFilter,
		setAdFilter: setAdFilter,
		
		setDefault: setDefault, /* 2.7 */
		getDefault: getDefault, /* 2.7 */
		
		getCurrentAd: getCurrentAd, /* 1.7 */
		
		logEvent: logEvent,
		
		openApplication: openApplication, /* 1.9 */
		openBrowser: openBrowser, /* 2.1 */
		callAppFunctionInterface: callAppFunctionInterface, /* 1.9 */
		
		isHypePreview: isHypePreview,
		isHypeIDE: isHypeIDE,
		
		filterBeginsWith: filterBeginsWith,
		filterContains: filterContains,
		
		triggerCustomEvent: triggerCustomEvent,/* 2.0 */
		globalCustomEvent: globalCustomEvent, /* 2.3 */
		
		enableCardInteraction: function(){
			if (_hypeDocument) _hypeDocument.enableCardInteraction()
		},
		
		nextCard: function(optionalTransition, optionalDuration){
			if (_hypeDocument) _hypeDocument.nextCard(optionalTransition, optionalDuration)
		},
		prevCard: function(optionalTransition, optionalDuration){
			if (_hypeDocument) _hypeDocument.prevCard(optionalTransition, optionalDuration)
		},
		gotoCard: function(name, optionalTransition, optionalDuration){ /* 2.6 */
			if (_hypeDocument) _hypeDocument.gotoCard(name, optionalTransition, optionalDuration)
		},

		/* 3.0.5 */
		prevCardWithBase: function(baseName, optionalTransition, optionalDuration){
			if (_hypeDocument) _hypeDocument.prevCardWithBase(baseName, optionalTransition, optionalDuration)
		},

		nextCardWithBase: function(baseName, optionalTransition, optionalDuration){
			if (_hypeDocument) _hypeDocument.nextCardWithBase(baseName, optionalTransition, optionalDuration)
		},

		defineCardSequence: function(cardArray){
			if (_hypeDocument) _hypeDocument.defineCardSequence(cardArray)
		},

		nextCardInSequence: function(optionalTransition, optionalDuration) {
			if (_hypeDocument) _hypeDocument.nextCardInSequence(optionalTransition, optionalDuration)
		},

		prevCardInSequence: function(optionalTransition, optionalDuration) {
			if (_hypeDocument) _hypeDocument.prevCardInSequence(transition, duration)
		},

		gotoCurrentCardInSequence: function(optionalTransition, optionalDuration) {
			if (_hypeDocument) _hypeDocument.gotoCurrentCardInSequence(transition, durationn)
		},

		getCurrentCardInSequence: function() {
			if (_hypeDocument) _hypeDocument.getCurrentCardInSequence()
		},
	};
	window['MobilePriceAd'] = API;
	return API;
})(); 

/* https://developer.mozilla.org/en-US/docs/Web/API/ChildNode/remove polyfill */
(function(b){b.forEach(function(a){a.hasOwnProperty("remove")||Object.defineProperty(a,"remove",{configurable:!0,enumerable:!0,writable:!0,value:function(){null!==this.parentNode&&this.parentNode.removeChild(this)}})})})([Element.prototype,CharacterData.prototype,DocumentType.prototype]);

/*
 Hype CommandPipeline 1.3
copyright (c) 2019 Max Ziebell, (https://maxziebell.de). MIT-license
*/
!1==="HypeCommandPipeline"in window&&(window.HypeCommandPipeline=function(){!1==="HYPE_eventListeners"in window&&(window.HYPE_eventListeners=[]);window.HYPE_eventListeners.push({type:"HypeTriggerCustomBehavior",callback:function(b,a,c){if(-1<c.customBehaviorName.indexOf("|")){a=c.customBehaviorName.split("|");try{var d=JSON.parse("["+a[1]+"]")}catch(e){alert("Hype CommandPipeline:\n"+e.name+": "+e.message)}"object"===typeof d&&(a=a[0].trim(),b.hasOwnProperty(a)&&"function"===typeof b[a]&&b[a].apply(b,
d))}}});return{version:"1.3"}}());

/*
 Hype GlobalBehavior 1.8
copyright (c) 2020 Max Ziebell, (https://maxziebell.de). MIT-license
*/
!1==="HypeGlobalBehavior"in window&&(window.HypeGlobalBehavior=function(){var e={},g=[],k=function(a,c,b){if("#"!=b.customBehaviorName.substr(0,1)){c=b.customBehaviorName.split("@");a=c.shift();if(window.hasOwnProperty("HYPE")&&window.HYPE.hasOwnProperty("documents")){c=0==c.length?Object.keys(window.HYPE.documents):c;for(var d in c)if(window.HYPE.documents.hasOwnProperty(c[d])){var f=window.HYPE.documents[c[d]];f.triggerCustomBehaviorNamed("#"+a);if(f.hasOwnProperty("onGlobalBehavior"))f.onGlobalBehavior("#"+
a)}}if(h.hasOwnProperty("onGlobalBehavior"))h.onGlobalBehavior("#"+a);d=!b.isBubbleDown&&!b.isBubbleUp;(b.isBubbleDown||d)&&n(a,null);if(b.isBubbleUp||d)window!=top&&window.parent.postMessage({type:"TriggerCustomBehaviorBubbleUp",customBehaviorName:a},"*"),b.childToAvoid&&n(a,b.childToAvoid)}return!0},n=function(a,c){[].forEach.call(document.querySelectorAll("iframe"),function(b){b=b.contentWindow;c!=b&&b.postMessage({type:"TriggerCustomBehaviorBubbleDown",customBehaviorName:a},"*")})},l=function(a){k(null,
null,{customBehaviorName:a})},p=function(a,c,b){if(null!=a&&null!=c&&!e.hasOwnProperty(a)){var d=c.hasOwnProperty("FPS")?1E3/c.FPS:1E3*c;b=b?b:{};b.hasOwnProperty("pattern")?(b._buf=b.pattern.slice(0),null==b.countdown&&(b.countdown=Infinity),c=function(){0==b._buf.length&&(b._buf=b.pattern.slice(0));b._buf.shift()&&l(a)}):c=function(){l(a)};e[a]=setInterval(c,d);b.omitFirst||c()}},m=function(a){e.hasOwnProperty(a)&&(clearInterval(e[a]),delete e[a])},q=function(){for(var a in e)m(a)};window.addEventListener("message",
function(a){if(g.length&&-1==g.indexOf(a.origin))console.log("Blocked behavior from "+a.origin);else if(a.data.hasOwnProperty("type")&&a.data.hasOwnProperty("customBehaviorName")){var c="TriggerCustomBehaviorBubbleUp"==a.data.type,b="TriggerCustomBehaviorBubbleDown"==a.data.type;(c||b)&&k(null,null,{customBehaviorName:a.data.customBehaviorName,isBubbleUp:c,isBubbleDown:b,childToAvoid:c?window:null})}},!1);!1==="HYPE_eventListeners"in window&&(window.HYPE_eventListeners=[]);window.HYPE_eventListeners.push({type:"HypeDocumentLoad",
callback:function(a,c,b){a.startCustomBehaviorTicker=function(d,f,r){p(d,f,r)};a.stopCustomBehaviorTicker=function(d){m(d)};a.stopAllCustomBehaviorTicker=function(){q()};return!0}});window.HYPE_eventListeners.push({type:"HypeTriggerCustomBehavior",callback:k});var h={version:"1.7",allowPostMessageFrom:function(a){g.push(a)},triggerCustomBehaviorNamed:l,startCustomBehaviorTicker:p,stopCustomBehaviorTicker:m,stopAllCustomBehaviorTicker:q};return h}());

/*
 Hype Action Events 1.1.2
copyright (c) 2022 Max Ziebell, (https://maxziebell.de). MIT-license
*/
!1==="HypeActionEvents"in window&&(window.HypeActionEvents=function(){function u(a){return a?w[a]:w}function A(a,e,l,c,p,f){if(-1!=u("MatterEvents").indexOf(p)&&e.querySelector("[data-"+f+"-action]"))Matter.Events.on(c,p,function(d){for(var b=d.pairs,h=0;h<b.length;h++){var n=document.getElementById(d.pairs[h].bodyA.elementId),r=document.getElementById(d.pairs[h].bodyB.elementId),g=n.getAttribute("data-"+f+"-action");g&&a.triggerAction(g,{element:n,event:Object.assign({type:d.name},d)});(g=r.getAttribute("data-"+
f+"-action"))&&a.triggerAction(g,{element:r,event:Object.assign({type:d.name},d)})}})}function x(a){return a.replaceAll(/[^a-zA-Z0-9\s]/g,"").replaceAll(/\s+/g,"-").toLowerCase()}var B="drag dragstart dragend dragover dragenter dragleave drop contextmenu keydown keypress keyup submit".split(" "),C="$ctx $doc $sym $elm $evt hypeDocument element event".split(" "),w={debug:!1,LegacyMode:!1,StrictMode:!1,MatterEvents:["collisionStart","collisionEnd","collisionActive"],DOMEvents:[].concat("mousedown mouseup click dblclick mouseover mousewheel mouseout mousemove touchstart touchmove touchend touchcancel change input beforeinput focusin focusout animationstart animationiteration animationend animationcancel transitionstart transitionrun transitionend transitioncancel pointerdown pointerup pointerover pointerout pointermove pointerenter pointerleave pointercancel".split(" ")).concat(B),
nonPassiveDOMEvents:B,WindowEvents:"resize focus blur beforeprint afterprint error storage online offline hashchange popstate message wheel".split(" "),DocumentEvents:["visibilitychange","scroll","fullscreenchange"]},k={};!1==="HYPE_eventListeners"in window&&(window.HYPE_eventListeners=[]);window.HYPE_eventListeners.push({type:"HypeDocumentLoad",callback:function(a,e,l){var c=a.documentId(),p=document.getElementById(c);k[a.documentId()]={rO:{},iO:{},mO:{},rAFiD:null,rAFsF:0,rAFtF:0,wE:{},dE:{}};u("DOMEvents").forEach(function(f){p.addEventListener(f,
function(d){var b=d.type,h=d.target.closest("#"+c+" [data-"+b+"-action]");h&&b&&(b=h.getAttribute("data-"+b+"-action"))&&a.triggerAction(b,{element:h,event:d})},{passive:-1==u("nonPassiveDOMEvents").indexOf(f)})});a.getSymbolInstance=function(f){for(var d=null;null==d&&null!=f;)d=a.getSymbolInstanceById(f.id),f=f.parentNode;return d};a.triggerAction=function(f,d){if(f){d=d||{};d=Object.assign({symbolInstance:a.getSymbolInstance(d.element),element:document.getElementById(a.currentSceneId()),event:{},
scope:a.customData},d);var b=d.strictMode||u("StrictMode"),h=a.functions();if(!b){var n=Object.assign({},a,d.symbolInstance);if(u("LegacyMode")){var r={};Object.keys(h).forEach(function(g){r[g]=h[g].bind(a,a,d.element,d.event)});n=Object.assign(n,r)}else n=new Proxy(n,{set:function(g,m,t,q){return Reflect.get(g,m,q)?Reflect.set(g,m,t,q):Reflect.set(d.scope,m,t)},get:function(g,m,t){var q=Reflect.get(h,m);return q?q.bind(a,a,d.element,d.event):(g=Reflect.get(g,m,t))?g:Reflect.get(d.scope,m)},has:function(g,
m,t){return-1!==C.indexOf(m)?!1:Reflect.get(h,m)||!g.hasOwnProperty(m)&&!window[m]?!0:Reflect.has(g,m,t)}})}d.symbolInstance&&Object.assign(d.event,{symbolInstance:d.symbolInstance});try{return Function(C,n?"with($ctx){"+f+"}":b?'"use strict";'+f:f)(n,a,d.symbolInstance,d.element,d.event,a,d.element,d.event)}catch(g){(u("debug")||-1!=window.location.href.indexOf("127.0.0.1:")&&-1!=window.location.href.indexOf("/preview/"))&&console.error("%c"+(d.errorMsg||"Hype Action Events Error")+"%c"+(d.errorMsg?
"":" version "+D.version)+"\n\n%c"+f+(d.omitError?"":"%c\n\n"+g+"\n\n"),"font-size:12px; font-weight:bold","font-size:8px","min-height:40px;display: inline-block; padding: 10px; background-color: rgba(255,255,255,0.25); border: 1px solid lightgray; border-radius: 4px; font-family:Monospace; font-size:12px","font-size:11px",d.element?d.element:"")}}};a.triggerActionsByAttribute=function(f,d,b){d=d||document.getElementById(a.currentSceneId());b=b||{};d.querySelectorAll("["+f+"]").forEach(function(h){var n=
h.getAttribute(f);n&&a.triggerAction(n,Object.assign({element:h},b))})};a.querySelector=function(f){return document.getElementById(a.currentSceneId()).querySelector(f)};a.querySelectorAll=function(f){return document.getElementById(a.currentSceneId()).querySelectorAll(f)};"function"==typeof a.functions().HypeActionEvents&&a.functions().HypeActionEvents(a,e,l)}});window.HYPE_eventListeners.push({type:"HypeLayoutRequest",callback:function(a,e,l){a.triggerActionsByAttribute("data-layout-request-action",
e,{event:l})}});window.HYPE_eventListeners.push({type:"HypeScenePrepareForDisplay",callback:function(a,e,l){a.triggerActionsByAttribute("data-scene-prepare-action",e,{event:l})}});window.HYPE_eventListeners.push({type:"HypeSceneLoad",callback:function(a,e,l){var c=a.documentId(),p=document.getElementById(c);a.triggerActionsByAttribute("data-scene-load-action",e,{event:l});0!="Matter"in window&&u("MatterEvents")&&u("MatterEvents").length&&(p=a.getElementProperty(p,"physics-engine"),A(a,e,l,p,"collisionStart",
"collision-start"),A(a,e,l,p,"collisionActive","collision-active"),A(a,e,l,p,"collisionEnd","collision-end"));e.querySelectorAll("[data-resize-action]").forEach(function(b){k[c].rO[b.id]||(k[c].rO[b.id]=new ResizeObserver(function(n,r){var g=b.getAttribute("data-resize-action");g&&n.forEach(function(m,t){a.triggerAction(g,{element:b,event:{type:"ResizeObserver",entry:m,index:t,entries:n,observer:r}})})}));var h=b.getAttribute("data-resize-target");k[c].rO[b.id].observe(h||b)});e.querySelectorAll("[data-intersection-action]").forEach(function(b){if(!k[c].iO[b.id]){var h=
b.getAttribute("data-intersection-root"),n=b.getAttribute("data-intersection-margin"),r=b.getAttribute("data-intersection-threshold");r=r?r.replace(/\s\s+/g," ").split(" ").map(function(g){return-1!==g.indexOf("%")?parseFloat(g)/100:parseFloat(g)}):u("IntersectionTreshold")||null;k[c].iO[b.id]=new IntersectionObserver(function(g,m){var t=b.getAttribute("data-intersection-action");t&&g.forEach(function(q,y){var v=0;q.isIntersecting&&r&&(v=r.reduce(function(z,E){return Math.abs(E-q.intersectionRatio)<
Math.abs(z-q.intersectionRatio)?E:z}));null==q.rootBounds&&(q.rootBounds={top:0,bottom:window.innerHeight});a.triggerAction(t,{element:b,event:{type:"IntersectionObserver",entry:q,index:y,entries:g,observer:m,closestThreshold:v,closestThresholdPercent:100*v,inViewport:q.boundingClientRect.top<=q.rootBounds.bottom&&q.boundingClientRect.bottom>q.rootBounds.top,isAbove:q.boundingClientRect.top<q.rootBounds.top,isBelow:q.boundingClientRect.bottom>q.rootBounds.bottom+1}})})},{root:e.querySelector(h)||
null,rootMargin:n||"0px",threshold:r||null})}h=b.getAttribute("data-intersection-target");k[c].iO[b.id].observe(h||b)});e.querySelectorAll("[data-mutation-action]").forEach(function(b){k[c].mO[b.id]||(k[c].mO[b.id]=new MutationObserver(function(t,q){var y=b.getAttribute("data-mutation-action");y&&t.forEach(function(v,z){a.triggerAction(y,{element:b,event:{type:"MutationObserver",mutation:v,index:z,mutations:t,observer:q}})})}));var h="true"==b.getAttribute("data-mutation-child-list"),n="true"==b.getAttribute("data-mutation-attributes")||
!0,r="true"==b.getAttribute("data-mutation-character-data"),g="true"==b.getAttribute("data-mutation-subtree"),m=b.getAttribute("data-mutation-attribute-filter");m=m?m.split(",").map(function(t){return t.trim()}):u("AttributeFilter")||null;h={childList:h,attributes:n,characterData:r,subtree:g};m&&h.assign(h,{attributeFilter:m});m=b.getAttribute("data-mutation-target");k[c].mO[b.id].observe(m||b,h)});var f=e.querySelectorAll("[data-animation-frame-action]");if(f){k[c].rAFsF=0;var d=function(b){f.forEach(function(h){var n=
h.getAttribute("data-animation-frame-action");n&&a.triggerAction(n,{element:h,event:{type:"AnimationFrame",time:b,sceneFrames:k[c].rAFsF++,totalFrames:k[c].rAFtF++}})});k[c].rAFiD=requestAnimationFrame(d)};k[c].rAFiD=requestAnimationFrame(d)}u("WindowEvents").forEach(function(b){var h=e.querySelectorAll("[data-window-"+b+"-action]");h&&(k[c].wE[b]=function(n){var r=n.type;h.forEach(function(g){if(g&&r){var m=g.getAttribute("data-window-"+b+"-action");m&&a.triggerAction(m,{element:g,event:n})}})},
window.addEventListener(b,k[c].wE[b],{passive:!0}))});u("DocumentEvents").forEach(function(b){var h=e.querySelectorAll("[data-document-"+b+"-action]");h&&(k[c].dE[b]=function(n){var r=n.type;h.forEach(function(g){if(g&&r){var m=g.getAttribute("data-document-"+b+"-action");m&&a.triggerAction(m,{element:g,event:n})}})},document.addEventListener(b,k[c].dE[b],{passive:!0}))})}});window.HYPE_eventListeners.push({type:"HypeSceneUnload",callback:function(a,e,l){var c=a.documentId();a.triggerActionsByAttribute("data-scene-unload-action",
e,{event:l});for(var p in k[c].rO)e.querySelectorAll("[data-resize-action]").forEach(function(f){k[c].rO[p].unobserve(document.getElementById(f.id))});for(p in k[c].iO)e.querySelectorAll("[data-intersection-action]").forEach(function(f){k[c].iO[p].unobserve(document.getElementById(f.id))});for(p in k[c].mO)k[c].mO[p].disconnect();k[c].rAFiD&&(cancelAnimationFrame(k[c].rAFiD),k[c].rAFiD=null);u("WindowEvents").forEach(function(f){k[c].wE[f]&&(window.removeEventListener(f,k[c].wE[f]),delete k[c].wE[f])});
u("DocumentEvents").forEach(function(f){k[c].dE[f]&&(document.removeEventListener(f,k[c].dE[f]),delete k[c].dE[f])})}});window.HYPE_eventListeners.push({type:"HypeSymbolLoad",callback:function(a,e,l){var c=document.getElementById(a.currentSceneId()),p=a.getSymbolInstanceById(e.id).symbolName();if("function"==typeof a.functions()[p])a.functions()[p](a,e,Object.assign({proactiveEvent:!0},l));a.triggerActionsByAttribute("data-symbol-load-action",c,{event:l});e=x(p);a.triggerActionsByAttribute("data-symbol-load-"+
e+"-action",c,{event:l})}});window.HYPE_eventListeners.push({type:"HypeSymbolUnload",callback:function(a,e,l){var c=document.getElementById(a.currentSceneId()),p=a.getSymbolInstanceById(e.id).symbolName();if("function"==typeof a.functions()[p])a.functions()[p](a,e,Object.assign({proactiveEvent:!0},l));a.triggerActionsByAttribute("data-symbol-unload-action",c,{event:l});e=x(p);a.triggerActionsByAttribute("data-symbol-unload-"+e+"-action",c,{event:l})}});window.HYPE_eventListeners.push({type:"HypeTriggerCustomBehavior",
callback:function(a,e,l){var c=l.customBehaviorName;/[;=()]/.test(c)?"#"!=c.charAt(0)&&a.triggerAction(c,{element:e,event:l}):(e=document.getElementById(a.currentSceneId()),a.triggerActionsByAttribute("data-behavior-action",e,{event:l}),c=x(l.customBehaviorName),a.triggerActionsByAttribute("data-behavior-"+c+"-action",e,{event:l}))}});window.HYPE_eventListeners.push({type:"HypeTimelineComplete",callback:function(a,e,l){e=document.getElementById(a.currentSceneId());a.triggerActionsByAttribute("data-timeline-complete-action",
e,{event:l});var c=x(l.timelineName);a.triggerActionsByAttribute("data-timeline-complete-"+c+"-action",e,{event:l})}});var D={version:"1.1.2",getDefault:u,setDefault:function(a,e){"object"==typeof a?w=a:w[a]=e}};return D}());

/*
 Hype Reactive Content 1.1.7
copyright (c) 2022 Max Ziebell, (https://maxziebell.de). MIT-license
*/
!1==="HypeReactiveContent"in window&&(window.HypeReactiveContent=function(){function e(a){return a?_default[a]:_default}function v(a,c){return a?a+"."+c:c}function w(a,c,d){d=d||"";return null==a||a[x]?a:new Proxy(a,{get:function(g,n,b){if("_key"===n)return d;if(n===x)return!0;g=Reflect.get(g,n,b);return"object"===typeof g?w(g,c,v(d,n)):g},set:function(g,n,b,f){var m=Reflect.set(g,n,b,f);c(n,b,g,f);return m}})}function A(a){if(!a[x])return a;var c={},d;for(d in a)if(a.hasOwnProperty(d)){var g=a[d];
c[d]="object"===typeof g?A(g):g}return c}function y(a){return function(){if(!a.timeout){var c=arguments;a.timeout=requestAnimationFrame(function(){a.apply(this,c);a.timeout=null}.bind(this))}}}function r(a,c,d,g){if(d){if("object"!==typeof d)return null}else{if(void 0===d)return null;d=c.customData}g=g||{};if(!1!=="HypeActionEvents"in window)return c.triggerAction(a,{element:g.element,event:{type:g.type},scope:d});try{var n=new Proxy(Object.assign({element:g.element,$elm:g.element},c),{set:function(b,
f,m,p){return Reflect.get(b,f,p)?Reflect.set(b,f,m,p):Reflect.set(d,f,m)},get:function(b,f,m){return(b=Reflect.get(b,f,m))?b:Reflect.get(d,f)},has:function(b,f,m){return b.hasOwnProperty(f)||window[f]?Reflect.has(b,f,m):!0}});return(new Function("$context","with($context){ "+a+"}"))(n)}catch(b){console.error(b)}}function z(a,c,d){return d?r("return "+d,a,null,{element:c,type:"HypeReactiveScope"}):null}function B(a,c){var d=c.closest("[data-scope]");return d?z(a,c,d.getAttribute("data-scope")):null}
function D(a,c,d){!1==="HypeActionEvents"in window&&(c=d.customBehaviorName,"#"!=c.charAt(0)&&/[;=()]/.test(c)&&r(c,a,a.customData))}var C=-1!=window.location.href.indexOf("/Hype/Scratch/HypeScratch.");_default={scopeSymbol:"\u21e2",visibilitySymbol:"\ud83d\udc41"};C&&(_default=Object.assign(_default,{highlightReactiveContent:!0,highlightVisibilityData:!0,highlightVisibilityArea:!0,highlightContentData:!0,highlightScopeData:!0}));var x=Symbol("isProxy");!1==="HYPE_eventListeners"in window&&(window.HYPE_eventListeners=
[]);window.HYPE_eventListeners.push({type:"HypeDocumentLoad",callback:function(a,c,d){function g(b,f,m,p,l){(p=b.closest("["+m+"-action]"))&&r(p.getAttribute(m+"-action"),a,null,{element:b,type:f});if((p=b.closest("["+m+"-behavior]"))&&!n[p.id]){n[p.id]=!0;var h=p.getAttribute(m+"-behavior");y(function(){a.triggerCustomBehaviorNamed(h)})()}}var n={};a.refreshReactiveContent=function(b,f,m,p){void 0===b||void 0===f||/[;=()]/.test(f)||a.triggerCustomBehaviorNamed(v(p._key,b)+" equals "+("string"===
typeof f?'"'+f+'"':f));void 0!==b&&(e("customDataUpdate")&&e("customDataUpdate")(b,f,m,p),a.triggerCustomBehaviorNamed("customData was changed"),a.triggerCustomBehaviorNamed(v(p._key,b)+" was updated"));f=document.getElementById(a.currentSceneId());n={};f.querySelectorAll("[data-content], [data-visibility]").forEach(function(l){var h=l.getAttribute("data-content"),k=l.getAttribute("data-visibility"),q=null,t=null,u=e("scopeSymbol").length;h&&(h=h.trim(),h.startsWith(e("scopeSymbol"))?(h=h.slice(u),
q=B(a,l)):h.includes(e("scopeSymbol"))&&(q=h.slice(0,h.indexOf(e("scopeSymbol"))),q=z(a,l,q),h=h.slice(h.indexOf(e("scopeSymbol"))+u)),h=r("return "+h,a,q,{element:l,type:"HypeReactiveContent"}),h=void 0!==h?h:"",h!==l.innerHTML&&(l.innerHTML=h,b&&g(l,"HypeReactiveContentChanged","data-content-changed",!0,!0)));k&&(k=k.trim(),k.startsWith(e("scopeSymbol"))?(k=k.slice(u),t=q):k.includes(e("scopeSymbol"))&&(t=k.slice(0,k.indexOf(e("scopeSymbol"))),t=z(a,l,t),k=k.slice(k.indexOf(e("scopeSymbol"))+u)),
k=r("return "+k,a,t,{element:l,type:"HypeReactiveVisibility"}),"none"==l.style.display&&(l.style.display="block"),k=k?"visible":"hidden",k!==l.style.visibility&&(l.style.visibility=k,b&&g(l,"HypeReactiveVisibiltyChanged","data-visibility-changed",!0,!0)))});!1!=="HypeDataMagic"in window&&HypeDataMagic.getDefault("refreshOnCustomData")&&a.refresh()};a.refreshReactiveContentDebounced=y(a.refreshReactiveContent);a.resolveClosestScope=function(b){return B(a,b)};a.enableReactiveCustomData=function(b){a.customData=
Object.assign(a.customData,b||{});a.customData=w(a.customData,a.refreshReactiveContentDebounced)};a.enableReactiveCustomData(e("customData")||{});a.functions().HypeReactiveContent&&a.functions().HypeReactiveContent(a,c,d)}});window.HYPE_eventListeners.push({type:"HypeScenePrepareForDisplay",callback:function(a,c,d){a.refreshReactiveContentDebounced()}});!1==="HypeActionEvents"in window&&window.HYPE_eventListeners.push({type:"HypeTriggerCustomBehavior",callback:D});C&&window.addEventListener("DOMContentLoaded",
function(a){e("highlightReactiveContent")&&(a=[],e("highlightContentData")&&(a=a.concat(["[data-content*='"+e("scopeSymbol")+"']{--color:#ffcccc;}","[data-content]{--color:#f8d54f;outline:1px solid #f8d54f;position:relative}","[data-content]::before{content:attr(data-content);font-family:Helvetica,Arial;line-height:11px;font-size:9px;font-weight:normal;padding:2px 5px;white-space:nowrap;max-height:16px;color:#000;text-align:center;background-color:var(--color);position:absolute;top:-15px;left:-1px;border-top-right-radius:.2rem;border-top-left-radius:.2rem;}"])),
e("highlightVisibilityData")&&(a=a.concat(["[data-visibility*='"+e("scopeSymbol")+"']{--color:#ffcccc;}","[data-visibility]{--color:#f8d54f;}","[data-visibility]::before{content:'"+e("visibilitySymbol")+" ' attr(data-visibility);font-family:Helvetica,Arial;line-height:11px;font-size:9px;font-weight:normal;padding:2px 5px;white-space:nowrap;max-height:16px;color:#000;text-align:center;background-color:var(--color);position:absolute;top:-15px;left:-1px;border-top-right-radius:.2rem;border-top-left-radius:.2rem;}"])),
e("highlightScopeData")&&(a=a.concat(["[data-scope]{--color:#ffcccc; outline:1px dashed var(--color);}","[data-scope]::before{content:attr(data-scope);font-family:Helvetica,Arial;line-height:11px;font-size:9px;font-weight:normal;padding:2px 5px;white-space:nowrap;max-height:16px;color:#000;text-align:center;background-color:var(--color);position:absolute;bottom:-15px;left:-1px;border-bottom-right-radius:.2rem;border-bottom-left-radius:.2rem}"])),e("highlightContentData")&&e("highlightVisibilityData")&&
(a=a.concat(["[data-content][data-visibility]::before{content: attr(data-content) ' "+e("visibilitySymbol")+" ' attr(data-visibility)}"])),e("highlightVisibilityArea")&&(a=a.concat(["[data-visibility]::after {content:'';position: absolute;top: 0;left: 0;width: 100%;height: 100%;background-image:repeating-linear-gradient(45deg,transparent,transparent 10px,var(--color) 10px,var(--color) 20px);opacity: .1;}"])),a.forEach(function(c){return document.styleSheets[0].insertRule(c,0)}))});return{version:"1.1.7",
setDefault:function(a,c){"object"==typeof a?_default=a:_default[a]=c},getDefault:e,enableReactiveObject:w,disableReactiveObject:A,debounceByRequestFrame:y}}());
